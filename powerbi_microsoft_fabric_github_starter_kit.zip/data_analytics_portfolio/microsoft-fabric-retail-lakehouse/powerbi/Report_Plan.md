# Power BI report plan
- KPI cards: Total Sales, Units Sold, Order Count.
- Line chart: Total Sales by Year-Month.
- Bar chart: Total Sales by Region.
- Matrix: Region x Category with Sales and Units.
- Slicers: Year-Month, Region, Category.
Validate report totals against SQL queries and document refresh behavior.
