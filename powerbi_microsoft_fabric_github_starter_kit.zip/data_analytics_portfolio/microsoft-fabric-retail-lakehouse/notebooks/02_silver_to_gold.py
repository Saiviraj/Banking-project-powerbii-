from pyspark.sql import functions as F

silver_df = spark.read.table("silver_retail_sales")
gold_df = (
    silver_df
    .withColumn("year_month", F.date_format("order_date", "yyyy-MM"))
    .groupBy("year_month", "region", "category")
    .agg(
        F.sum("sales_amount").alias("total_sales"),
        F.sum("quantity").alias("units_sold"),
        F.countDistinct("order_id").alias("order_count"),
        F.avg("sales_amount").alias("average_line_amount")
    )
)
gold_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("gold_sales_summary")
display(gold_df.orderBy("year_month", "region").limit(20))
