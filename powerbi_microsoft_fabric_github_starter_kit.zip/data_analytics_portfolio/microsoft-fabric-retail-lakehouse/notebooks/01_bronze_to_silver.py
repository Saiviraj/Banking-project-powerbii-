from pyspark.sql import functions as F

source_path = "Files/retail_sales.csv"
bronze_df = spark.read.option("header", True).option("inferSchema", True).csv(source_path)

silver_df = (
    bronze_df
    .withColumn("order_date", F.to_date("order_date"))
    .withColumn("sales_amount", F.col("sales_amount").cast("double"))
    .withColumn("quantity", F.col("quantity").cast("int"))
    .withColumn("region", F.initcap(F.trim(F.col("region"))))
    .withColumn("category", F.trim(F.col("category")))
    .dropDuplicates(["order_id", "product_id"])
    .filter(F.col("order_id").isNotNull())
    .filter(F.col("order_date").isNotNull())
    .filter(F.col("sales_amount") >= 0)
    .filter(F.col("quantity") > 0)
)
silver_df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable("silver_retail_sales")
display(silver_df.limit(10))
