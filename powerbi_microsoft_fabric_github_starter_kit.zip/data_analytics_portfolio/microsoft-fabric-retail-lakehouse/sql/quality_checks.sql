SELECT order_id, product_id, COUNT(*) AS row_count
FROM silver_retail_sales
GROUP BY order_id, product_id
HAVING COUNT(*) > 1;

SELECT COUNT(*) AS invalid_rows
FROM silver_retail_sales
WHERE sales_amount < 0 OR sales_amount IS NULL;

SELECT year_month, SUM(total_sales) AS monthly_sales
FROM gold_sales_summary
GROUP BY year_month
ORDER BY year_month;
