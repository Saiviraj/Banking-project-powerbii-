# Retail Analytics Lakehouse — Microsoft Fabric
An end-to-end starter project blueprint using synthetic retail data.

## Architecture
CSV -> Lakehouse Bronze/raw -> PySpark cleansing -> Silver Delta table -> Gold aggregate -> SQL analytics endpoint/semantic model -> Power BI.

## Suggested Fabric items
- Lakehouse: `RetailLakehouse`
- Notebook: `01_bronze_to_silver`
- Notebook: `02_silver_to_gold`
- Pipeline: `Retail_Refresh_Pipeline`
- Gold table: `gold_sales_summary`

## Build steps
1. Create a Fabric-enabled workspace and Lakehouse.
2. Upload `data/retail_sales.csv` into the Lakehouse Files area.
3. Adapt and run the notebook starters in your Fabric workspace.
4. Create a pipeline to orchestrate the notebook activities.
5. Connect Power BI to the Gold table/semantic model and build a report.
6. Add screenshots and update this README with what you actually tested.

The files here are starter code, not a deployed workspace or finished PBIX. Do not claim scheduling or deployment until you configure and verify it.
