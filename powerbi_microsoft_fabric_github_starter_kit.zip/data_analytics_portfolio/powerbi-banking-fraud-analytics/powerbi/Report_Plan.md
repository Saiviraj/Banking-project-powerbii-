# Report pages
1. Executive overview: KPI cards, transaction trends over time, amount by transaction type, date/region/channel slicers.
2. Review activity: review-flag counts by type, region/channel matrix, transaction detail table with conditional formatting.
3. Customer patterns: volume and amount by customer segment, average amount by region.

Suggested screenshots: overview, review activity, and customer patterns.
