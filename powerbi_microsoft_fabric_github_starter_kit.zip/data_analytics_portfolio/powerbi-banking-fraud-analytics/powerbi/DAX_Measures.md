Assumes the fact table is named `transactions`.

```DAX
Total Transactions = COUNTROWS(transactions)

Total Transaction Amount = SUM(transactions[amount])

Average Transaction Amount =
DIVIDE([Total Transaction Amount], [Total Transactions])

Transactions Flagged for Review =
CALCULATE([Total Transactions], transactions[review_flag] = "Yes")

Review Flag Rate =
DIVIDE([Transactions Flagged for Review], [Total Transactions], 0)

Amount Flagged for Review =
CALCULATE([Total Transaction Amount], transactions[review_flag] = "Yes")
```
Format amount measures as currency and rate measures as percentages. Validate totals against the source CSV.
