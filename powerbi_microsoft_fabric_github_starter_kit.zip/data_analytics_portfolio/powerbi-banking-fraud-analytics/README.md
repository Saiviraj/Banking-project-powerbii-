# Banking Transaction & Review Analytics — Power BI
Personal portfolio project using synthetic data; no real customer or bank data is included.

## Goals
- Clean and validate transaction data in Power Query or SQL.
- Model transactions with customer and date dimensions.
- Build DAX measures and interactive Power BI report pages.
- Analyze transaction volume, transaction values, and records flagged for review.

## Build
1. Load `data/transactions.csv` and `data/customers.csv` into Power BI Desktop.
2. Set data types, check nulls and duplicates, and create a Date table.
3. Create relationships from customers and dates to transactions.
4. Add the measures in `powerbi/DAX_Measures.md`.
5. Follow `powerbi/Report_Plan.md`, save your finished PBIX, and add report screenshots.

A review flag is not proof of fraud. Describe this as a synthetic learning project, not production banking experience.
