-- Suggested semantic model:
-- FactTransactions: transaction_id, customer_id, transaction_date,
-- amount, transaction_type, channel, region, review_flag
-- DimCustomer: customer_id, customer_segment, customer_region
-- DimDate: date, year, month_number, month_name, quarter
--
-- Power BI relationships:
-- DimCustomer[customer_id] 1 -> * FactTransactions[customer_id]
-- DimDate[Date]             1 -> * FactTransactions[transaction_date]
--
-- Example SQL aggregation:
SELECT
    transaction_type,
    channel,
    review_flag,
    COUNT(*) AS transaction_count,
    SUM(amount) AS total_amount,
    AVG(amount) AS average_amount
FROM transactions
GROUP BY transaction_type, channel, review_flag;
