-- Duplicate transaction IDs
SELECT transaction_id, COUNT(*) AS row_count
FROM transactions GROUP BY transaction_id HAVING COUNT(*) > 1;

-- Missing key fields / invalid amounts
SELECT *
FROM transactions
WHERE transaction_id IS NULL OR customer_id IS NULL
   OR transaction_date IS NULL OR amount IS NULL OR amount < 0;

-- Review flag distribution
SELECT review_flag, COUNT(*) AS transaction_count
FROM transactions GROUP BY review_flag;
