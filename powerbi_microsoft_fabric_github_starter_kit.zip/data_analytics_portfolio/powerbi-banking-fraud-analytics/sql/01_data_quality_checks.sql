-- Run these checks after loading the CSVs into a SQL database.
-- Adjust table/schema names for your environment.

-- 1. Duplicate transaction IDs
SELECT transaction_id, COUNT(*) AS row_count
FROM transactions
GROUP BY transaction_id
HAVING COUNT(*) > 1;

-- 2. Missing required values
SELECT
    SUM(CASE WHEN transaction_id IS NULL THEN 1 ELSE 0 END) AS missing_transaction_id,
    SUM(CASE WHEN customer_id IS NULL THEN 1 ELSE 0 END) AS missing_customer_id,
    SUM(CASE WHEN transaction_date IS NULL THEN 1 ELSE 0 END) AS missing_transaction_date,
    SUM(CASE WHEN amount IS NULL THEN 1 ELSE 0 END) AS missing_amount
FROM transactions;

-- 3. Invalid amounts
SELECT *
FROM transactions
WHERE amount < 0;

-- 4. Flagged transaction distribution
SELECT review_flag, COUNT(*) AS transaction_count
FROM transactions
GROUP BY review_flag;
