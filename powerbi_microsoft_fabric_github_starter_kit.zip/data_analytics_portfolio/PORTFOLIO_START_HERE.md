# Data Engineering + BI Portfolio Starter Kit
1. `powerbi-banking-fraud-analytics`: synthetic banking data, SQL validation, DAX measures, and dashboard plan.
2. `microsoft-fabric-retail-lakehouse`: synthetic retail data, PySpark notebook starters, SQL checks, and Power BI report plan.

Before publishing: build and save your own PBIX files, test notebooks in your Fabric workspace, add screenshots, and update READMEs to reflect what you actually implemented.
